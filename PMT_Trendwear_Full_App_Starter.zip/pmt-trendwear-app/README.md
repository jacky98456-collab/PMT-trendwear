# PMT Trendwear — Cross-platform PWA starter

A responsive starter storefront for iPhone, iPad, and Android. It includes a product grid, size picker, persistent local cart, checkout form/order summary, and a 3D model viewer that can load a local `.glb` / `.gltf` file.

## Run locally

1. Unzip the project.
2. Open `index.html` in a modern browser to test the storefront. For service worker/PWA behavior, use an HTTPS host or local web server.
3. Product data and sample prices are in the `PRODUCTS` array near the bottom of `index.html`.

## Publish free with GitHub Pages

1. Sign in or create an account at https://github.com/.
2. Create a **public** repository named `pmt-trendwear`.
3. Upload the contents of this folder (make sure `index.html` is in the repository root, not inside another nested folder).
4. Open repository **Settings → Pages**.
5. Under Build and deployment, choose **Deploy from a branch**, select `main` and `/ (root)`, then Save.
6. Wait for the Pages deployment to finish. GitHub will show the real public URL in Settings → Pages. It typically looks like `https://YOUR-USERNAME.github.io/pmt-trendwear/` — replace with the exact URL GitHub gives you.

## Add to home screen

- iPhone/iPad: open the published HTTPS URL in Safari → Share → Add to Home Screen.
- Android: open the URL in Chrome → menu → Install app / Add to Home screen.

## Add your real 3D garment

- Export your garment from Blender or another 3D tool as `.glb` (recommended) or `.gltf`.
- Use the 3D Viewer section's file picker to test a model locally.
- For a model visible to every visitor, place it at `models/technical-top.glb`, then change the viewer placeholder in `index.html` to a `<model-viewer src="models/technical-top.glb" camera-controls auto-rotate ...>` element. Do not publish a private/incorrect model as the final design.
- The current garment drawing is a concept placeholder, not a production-accurate 3D model. The PMT wordmark is illustrative; replace it with the official logo asset after confirming the exact artwork.

## Before taking real orders

This is a frontend demo, not a complete production commerce system. Cart data is stored in the customer's browser. Checkout only formats an order summary for copying/downloading; it does not transmit orders, reserve inventory, calculate shipping, or process payments. Before launch, add a backend/order service or connect a hosted commerce platform, and configure real prices, product images, inventory, privacy policy, shipping/returns, contact details, and payment options. Never collect payment card details directly in this static page.

## Notes

- The 3D viewer loads Google's `<model-viewer>` library from a CDN, so a network connection is needed for that feature.
- The PWA shell can cache core files after the first online visit, but this does not make checkout/order storage server-backed.
